from django.shortcuts import render
from appointments.models import *
from appointments.serializers import *
from rest_framework.response import Response
from django.views.decorators.csrf import csrf_exempt
from rest_framework.views import APIView
from rest_framework import status

class DoctorList(APIView):
    def get(self, request):
        doctors = Doctor.objects.all()
        serializer = DoctorSerializer(doctors, many=True)
        return Response(serializer.data)

class PatientList(APIView):
    def get(self, request):
        patients = Patient.objects.all()
        serializer = PatientSerializer(patients, many=True)
        return Response(serializer.data)
    
class AppointmentList(APIView):
    def get(self, request):
        appointment = Appointment.objects.all()
        serializer = AppointmentSerializer(appointment, many=True)
        return Response(serializer.data)
    
    def post(self, request):
        serializer = Manage_AppointmentSerializer(data=request.data)
        if(serializer.is_valid()):
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class AppointmentDetail(APIView):
    def get(self, request, app_id):
        appointment = Appointment.objects.get(pk = app_id)
        serializer = AppointmentSerializer(appointment)
        return Response(serializer.data)
    def put(self, request, app_id):
        appointment = Appointment.objects.get(pk = app_id)
        serializer = Manage_AppointmentSerializer(appointment, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    def delete(self, request, app_id):
        appointment = Appointment.objects.get(pk = app_id)
        appointment.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
